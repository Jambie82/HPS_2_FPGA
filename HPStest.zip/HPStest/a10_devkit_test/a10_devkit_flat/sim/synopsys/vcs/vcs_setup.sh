
# (C) 2001-2018 Intel Corporation. All rights reserved.
# Your use of Intel Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Intel 
# Program License Subscription Agreement, Intel MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Intel and sold by Intel 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 17.0.2 297 win32 2018.01.17.11:15:38

# ----------------------------------------
# vcs - auto-generated simulation script

# ----------------------------------------
# This script provides commands to simulate the following IP detected in
# your Quartus project:
#     ghrd_10as066n2_onchip_memory2_0.ghrd_10as066n2_onchip_memory2_0
#     ghrd_10as066n2_pb_lwh2f.ghrd_10as066n2_pb_lwh2f
#     ghrd_10as066n2_f2sdram_m1.ghrd_10as066n2_f2sdram_m1
#     fifo_FPGA_to_HPS.fifo_FPGA_to_HPS
#     ghrd_10as066n2_led_pio.ghrd_10as066n2_led_pio
#     ghrd_10as066n2_clk_0.ghrd_10as066n2_clk_0
#     ghrd_10as066n2_emif_a10_hps_0.ghrd_10as066n2_emif_a10_hps_0
#     fifo_HPS_to_FPGA.fifo_HPS_to_FPGA
#     ghrd_10as066n2_f2sdram_m.ghrd_10as066n2_f2sdram_m
#     ghrd_10as066n2_fpga_m.ghrd_10as066n2_fpga_m
#     a10_devkit_flat.a10_devkit_flat
# 
# Intel recommends that you source this Quartus-generated IP simulation
# script from your own customized top-level script, and avoid editing this
# generated script.
# 
# To write a top-level shell script that compiles Intel simulation libraries
# and the Quartus-generated IP in your project, along with your design and
# testbench files, follow the guidelines below.
# 
# 1) Copy the shell script text from the TOP-LEVEL TEMPLATE section
# below into a new file, e.g. named "vcs_sim.sh".
# 
# 2) Copy the text from the DESIGN FILE LIST & OPTIONS TEMPLATE section into
# a separate file, e.g. named "filelist.f".
# 
# ----------------------------------------
# # TOP-LEVEL TEMPLATE - BEGIN
# #
# # TOP_LEVEL_NAME is used in the Quartus-generated IP simulation script to
# # set the top-level simulation or testbench module/entity name.
# #
# # QSYS_SIMDIR is used in the Quartus-generated IP simulation script to
# # construct paths to the files required to simulate the IP in your Quartus
# # project. By default, the IP script assumes that you are launching the
# # simulator from the IP script location. If launching from another
# # location, set QSYS_SIMDIR to the output directory you specified when you
# # generated the IP script, relative to the directory from which you launch
# # the simulator.
# #
# # Source the Quartus-generated IP simulation script and do the following:
# # - Compile the Quartus EDA simulation library and IP simulation files.
# # - Specify TOP_LEVEL_NAME and QSYS_SIMDIR.
# # - Compile the design and top-level simulation module/entity using
# #   information specified in "filelist.f".
# # - Override the default USER_DEFINED_SIM_OPTIONS. For example, to run
# #   until $finish(), set to an empty string: USER_DEFINED_SIM_OPTIONS="".
# # - Run the simulation.
# #
# source <script generation output directory>/synopsys/vcs/vcs_setup.sh \
# TOP_LEVEL_NAME=<simulation top> \
# QSYS_SIMDIR=<script generation output directory> \
# USER_DEFINED_ELAB_OPTIONS="\"-f filelist.f\"" \
# USER_DEFINED_SIM_OPTIONS=<simulation options for your design>
# #
# # TOP-LEVEL TEMPLATE - END
# ----------------------------------------
# 
# ----------------------------------------
# # DESIGN FILE LIST & OPTIONS TEMPLATE - BEGIN
# #
# # Compile all design files and testbench files, including the top level.
# # (These are all the files required for simulation other than the files
# # compiled by the Quartus-generated IP simulation script)
# #
# +systemverilogext+.sv
# <design and testbench files, compile-time options, elaboration options>
# #
# # DESIGN FILE LIST & OPTIONS TEMPLATE - END
# ----------------------------------------
# 
# IP SIMULATION SCRIPT
# ----------------------------------------
# ACDS 17.0.2 297 win32 2018.01.17.11:15:38
# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="a10_devkit_flat"
QSYS_SIMDIR="./../../"
QUARTUS_INSTALL_DIR="C:/intelfpga_pro/17.0/quartus/"
SKIP_FILE_COPY=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="+vcs+finish+100"
# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# initialize simulation properties - DO NOT MODIFY!
ELAB_OPTIONS=""
SIM_OPTIONS=""
if [[ `vcs -platform` != *"amd64"* ]]; then
  :
else
  :
fi

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/altera_avalon_onchip_memory2_170/sim/ghrd_10as066n2_onchip_memory2_0_onchip_memory2_0.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_params_sim.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_params_synth.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_cal.hex ./
fi

vcs -lca -timescale=1ps/1ps -sverilog +verilog2001ext+.v -ntb_opts dtm $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v \
  $QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_atoms.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_hssi_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_hssi_atoms.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_hip_atoms_ncrypt.v \
  -v $QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_hip_atoms.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/altera_avalon_onchip_memory2_170/sim/ghrd_10as066n2_onchip_memory2_0_altera_avalon_onchip_memory2_170_gyvpreq.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/sim/ghrd_10as066n2_onchip_memory2_0.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_pb_lwh2f/altera_avalon_mm_bridge_170/sim/altera_avalon_mm_bridge.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_pb_lwh2f/sim/ghrd_10as066n2_pb_lwh2f.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_jtag_interface.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_dc_streaming.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_sld_node.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_streaming.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_clock_crosser.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_std_synchronizer_nocut.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_base.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_remover.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_inserter.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_stage.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/timing_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_timing_adapter_170_osazali.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_sc_fifo_170/sim/altera_avalon_sc_fifo.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_st_bytes_to_packets_170/sim/altera_avalon_st_bytes_to_packets.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_st_packets_to_bytes_170/sim/altera_avalon_st_packets_to_bytes.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_packets_to_master_170/sim/altera_avalon_packets_to_master.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_channel_adapter_170_bsi6toa.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_channel_adapter_170_xbvi4ny.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_reset_controller_170/sim/altera_reset_controller.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_reset_controller_170/sim/altera_reset_synchronizer.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_f2sdram_m1_altera_jtag_avalon_master_170_vrhafhi.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/sim/ghrd_10as066n2_f2sdram_m1.v \
  $QSYS_SIMDIR/../../fifo_FPGA_to_HPS/fifo_FPGA_to_HPS/altera_avalon_fifo_170/sim/fifo_FPGA_to_HPS_altera_avalon_fifo_170_gadxcxi.v \
  $QSYS_SIMDIR/../../fifo_FPGA_to_HPS/fifo_FPGA_to_HPS/sim/fifo_FPGA_to_HPS.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_led_pio/altera_avalon_pio_170/sim/ghrd_10as066n2_led_pio_altera_avalon_pio_170_mhi24dy.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_led_pio/sim/ghrd_10as066n2_led_pio.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_clk_0/sim/ghrd_10as066n2_clk_0.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_top.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_io_aux.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_bufs.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_se_i.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_se_o.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_df_i.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_df_o.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_cp_i.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_bdir_df.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_bdir_se.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_unused.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_cal_counter.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll_fast_sim.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll_extra_clks.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_oct.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_core_clks_rsts.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hps_clks_rsts.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles_wrap.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_abphy_mux.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_avl_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_sideband_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_mmr_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_amm_data_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_ast_data_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_afi_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_seq_if.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_regs.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_oct.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_oct_um_fsm.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/mem_array_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_encrypted_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_nf5es_encrypted_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/io_12_lane_bcm__nf5es_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/io_12_lane__nf5es_abphy.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_a10_hps_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_a10_hps_170_65u4ugq.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/sim/ghrd_10as066n2_emif_a10_hps_0.v \
  $QSYS_SIMDIR/../../fifo_HPS_to_FPGA/fifo_HPS_to_FPGA/altera_avalon_fifo_170/sim/fifo_HPS_to_FPGA_altera_avalon_fifo_170_gadxcxi.v \
  $QSYS_SIMDIR/../../fifo_HPS_to_FPGA/fifo_HPS_to_FPGA/sim/fifo_HPS_to_FPGA.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/timing_adapter_170/sim/ghrd_10as066n2_f2sdram_m_timing_adapter_170_osazali.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m_channel_adapter_170_bsi6toa.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m_channel_adapter_170_xbvi4ny.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_f2sdram_m_altera_jtag_avalon_master_170_vrhafhi.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/sim/ghrd_10as066n2_f2sdram_m.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/timing_adapter_170/sim/ghrd_10as066n2_fpga_m_timing_adapter_170_osazali.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/channel_adapter_170/sim/ghrd_10as066n2_fpga_m_channel_adapter_170_bsi6toa.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/channel_adapter_170/sim/ghrd_10as066n2_fpga_m_channel_adapter_170_xbvi4ny.sv \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_fpga_m_altera_jtag_avalon_master_170_vrhafhi.v \
  $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/sim/ghrd_10as066n2_fpga_m.v \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/verbosity_pkg.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_utilities_pkg.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_mm_pkg.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_mm_slave_bfm.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/questa_mvc_svapi.svh \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_common_axi.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_axi_master.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_axi_slave.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_interrupt_sink.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_clock_source.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_reset_source.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_emif.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2h_axi_reset.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_h2f_lw_axi_reset.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_h2f_axi_reset.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2sdram0_reset.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2sdram2_reset.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_auzrmda_hps_io.sv \
  $QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_auzrmda.sv \
  $QSYS_SIMDIR/../altera_arria10_hps_io_170/sim/a10_devkit_flat_altera_arria10_hps_io_170_ka2odti.v \
  $QSYS_SIMDIR/../altera_arria10_hps_170/sim/a10_devkit_flat_altera_arria10_hps_170_qj4va5q.v \
  $QSYS_SIMDIR/../altera_avalon_sysid_qsys_170/sim/a10_devkit_flat_altera_avalon_sysid_qsys_170_g4vi2bq.v \
  $QSYS_SIMDIR/../altera_merlin_slave_translator_170/sim/altera_merlin_slave_translator.sv \
  $QSYS_SIMDIR/../altera_merlin_axi_master_ni_170/sim/altera_merlin_axi_master_ni.sv \
  $QSYS_SIMDIR/../altera_merlin_axi_master_ni_170/sim/altera_merlin_address_alignment.sv \
  $QSYS_SIMDIR/../altera_merlin_slave_agent_170/sim/altera_merlin_slave_agent.sv \
  $QSYS_SIMDIR/../altera_merlin_slave_agent_170/sim/altera_merlin_burst_uncompressor.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_kdhra7q.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_zislbwi.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_g4h2evy.sv \
  $QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_merlin_traffic_limiter.sv \
  $QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_merlin_reorder_memory.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_uncmpr.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_13_1.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_new.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_incr_burst_converter.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_wrap_burst_converter.sv \
  $QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_default_burst_converter.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_ncju4nq.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_sr2bqxy.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_ltwxniy.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_umxjhia.sv \
  $QSYS_SIMDIR/../altera_merlin_width_adapter_170/sim/altera_merlin_width_adapter.sv \
  $QSYS_SIMDIR/../error_adapter_170/sim/a10_devkit_flat_error_adapter_170_mtlhioy.sv \
  $QSYS_SIMDIR/../altera_avalon_st_adapter_170/sim/a10_devkit_flat_altera_avalon_st_adapter_170_4tlgflq.v \
  $QSYS_SIMDIR/../error_adapter_170/sim/a10_devkit_flat_error_adapter_170_7nlkpjq.sv \
  $QSYS_SIMDIR/../altera_avalon_st_adapter_170/sim/a10_devkit_flat_altera_avalon_st_adapter_170_4cxgu5y.v \
  $QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_bedsd2q.v \
  $QSYS_SIMDIR/../altera_merlin_master_translator_170/sim/altera_merlin_master_translator.sv \
  $QSYS_SIMDIR/../altera_merlin_master_agent_170/sim/altera_merlin_master_agent.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_ehtz4ty.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_cmmikbq.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_azcyaiy.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_7uqpf4y.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_qsfnafa.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_q5jdrzq.sv \
  $QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_e4h5cyi.v \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_s5homzq.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_3nv7wii.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_utyci7y.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_rodx5ey.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_dgamxba.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_xd2cdda.sv \
  $QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_yclsorq.v \
  $QSYS_SIMDIR/../altera_merlin_axi_slave_ni_170/sim/altera_merlin_axi_slave_ni.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_5fjswha.sv \
  $QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_dlzuccy.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_haephni.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_yfjobkq.sv \
  $QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_v76hp2y.sv \
  $QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_ek47qgi.sv \
  $QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_bpwwuey.v \
  $QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_piph77i.v \
  $QSYS_SIMDIR/a10_devkit_flat.v \
  -top $TOP_LEVEL_NAME
# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  ./simv $SIM_OPTIONS $USER_DEFINED_SIM_OPTIONS
fi
