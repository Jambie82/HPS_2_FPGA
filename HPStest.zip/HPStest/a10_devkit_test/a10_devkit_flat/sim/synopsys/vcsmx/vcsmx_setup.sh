
# (C) 2001-2018 Intel Corporation. All rights reserved.
# Your use of Intel Corporation's design tools, logic functions and 
# other software and tools, and its AMPP partner logic functions, and 
# any output files any of the foregoing (including device programming 
# or simulation files), and any associated documentation or information 
# are expressly subject to the terms and conditions of the Intel 
# Program License Subscription Agreement, Intel MegaCore Function 
# License Agreement, or other applicable license agreement, including, 
# without limitation, that your use is for the sole purpose of 
# programming logic devices manufactured by Intel and sold by Intel 
# or its authorized distributors. Please refer to the applicable 
# agreement for further details.

# ACDS 17.0.2 297 win32 2018.01.17.11:15:38

# ----------------------------------------
# vcsmx - auto-generated simulation script

# ----------------------------------------
# This script provides commands to simulate the following IP detected in
# your Quartus project:
#     ghrd_10as066n2_onchip_memory2_0.ghrd_10as066n2_onchip_memory2_0
#     ghrd_10as066n2_pb_lwh2f.ghrd_10as066n2_pb_lwh2f
#     ghrd_10as066n2_f2sdram_m1.ghrd_10as066n2_f2sdram_m1
#     fifo_FPGA_to_HPS.fifo_FPGA_to_HPS
#     ghrd_10as066n2_led_pio.ghrd_10as066n2_led_pio
#     ghrd_10as066n2_clk_0.ghrd_10as066n2_clk_0
#     ghrd_10as066n2_emif_a10_hps_0.ghrd_10as066n2_emif_a10_hps_0
#     fifo_HPS_to_FPGA.fifo_HPS_to_FPGA
#     ghrd_10as066n2_f2sdram_m.ghrd_10as066n2_f2sdram_m
#     ghrd_10as066n2_fpga_m.ghrd_10as066n2_fpga_m
#     a10_devkit_flat.a10_devkit_flat
# 
# Intel recommends that you source this Quartus-generated IP simulation
# script from your own customized top-level script, and avoid editing this
# generated script.
# 
# To write a top-level shell script that compiles Intel simulation libraries 
# and the Quartus-generated IP in your project, along with your design and
# testbench files, copy the text from the TOP-LEVEL TEMPLATE section below
# into a new file, e.g. named "vcsmx_sim.sh", and modify text as directed.
# 
# You can also modify the simulation flow to suit your needs. Set the
# following variables to 1 to disable their corresponding processes:
# - SKIP_FILE_COPY: skip copying ROM/RAM initialization files
# - SKIP_DEV_COM: skip compiling the Quartus EDA simulation library
# - SKIP_COM: skip compiling Quartus-generated IP simulation files
# - SKIP_ELAB and SKIP_SIM: skip elaboration and simulation
# 
# ----------------------------------------
# # TOP-LEVEL TEMPLATE - BEGIN
# #
# # QSYS_SIMDIR is used in the Quartus-generated IP simulation script to
# # construct paths to the files required to simulate the IP in your Quartus
# # project. By default, the IP script assumes that you are launching the
# # simulator from the IP script location. If launching from another
# # location, set QSYS_SIMDIR to the output directory you specified when you
# # generated the IP script, relative to the directory from which you launch
# # the simulator. In this case, you must also copy the generated library
# # setup "synopsys_sim.setup" into the location from which you launch the
# # simulator, or incorporate into any existing library setup.
# #
# # Run Quartus-generated IP simulation script once to compile Quartus EDA
# # simulation libraries and Quartus-generated IP simulation files, and copy
# # any ROM/RAM initialization files to the simulation directory.
# #
# # - If necessary, specify any compilation options:
# #   USER_DEFINED_COMPILE_OPTIONS
# #   USER_DEFINED_VHDL_COMPILE_OPTIONS applied to vhdl compiler
# #   USER_DEFINED_VERILOG_COMPILE_OPTIONS applied to verilog compiler
# #
# source <script generation output directory>/synopsys/vcsmx/vcsmx_setup.sh \
# SKIP_ELAB=1 \
# SKIP_SIM=1 \
# USER_DEFINED_COMPILE_OPTIONS=<compilation options for your design> \
# USER_DEFINED_VHDL_COMPILE_OPTIONS=<VHDL compilation options for your design> \
# USER_DEFINED_VERILOG_COMPILE_OPTIONS=<Verilog compilation options for your design> \
# QSYS_SIMDIR=<script generation output directory>
# #
# # Compile all design files and testbench files, including the top level.
# # (These are all the files required for simulation other than the files
# # compiled by the IP script)
# #
# vlogan <compilation options> <design and testbench files>
# #
# # TOP_LEVEL_NAME is used in this script to set the top-level simulation or
# # testbench module/entity name.
# #
# # Run the IP script again to elaborate and simulate the top level:
# # - Specify TOP_LEVEL_NAME and USER_DEFINED_ELAB_OPTIONS.
# # - Override the default USER_DEFINED_SIM_OPTIONS. For example, to run
# #   until $finish(), set to an empty string: USER_DEFINED_SIM_OPTIONS="".
# #
# source <script generation output directory>/synopsys/vcsmx/vcsmx_setup.sh \
# SKIP_FILE_COPY=1 \
# SKIP_DEV_COM=1 \
# SKIP_COM=1 \
# TOP_LEVEL_NAME="'-top <simulation top>'" \
# QSYS_SIMDIR=<script generation output directory> \
# USER_DEFINED_ELAB_OPTIONS=<elaboration options for your design> \
# USER_DEFINED_SIM_OPTIONS=<simulation options for your design>
# #
# # TOP-LEVEL TEMPLATE - END
# ----------------------------------------
# 
# IP SIMULATION SCRIPT
# ----------------------------------------
# ACDS 17.0.2 297 win32 2018.01.17.11:15:38
# ----------------------------------------
# initialize variables
TOP_LEVEL_NAME="a10_devkit_flat.a10_devkit_flat"
QSYS_SIMDIR="./../../"
QUARTUS_INSTALL_DIR="C:/intelfpga_pro/17.0/quartus/"
SKIP_FILE_COPY=0
SKIP_DEV_COM=0
SKIP_COM=0
SKIP_ELAB=0
SKIP_SIM=0
USER_DEFINED_ELAB_OPTIONS=""
USER_DEFINED_SIM_OPTIONS="+vcs+finish+100"

# ----------------------------------------
# overwrite variables - DO NOT MODIFY!
# This block evaluates each command line argument, typically used for 
# overwriting variables. An example usage:
#   sh <simulator>_setup.sh SKIP_SIM=1
for expression in "$@"; do
  eval $expression
  if [ $? -ne 0 ]; then
    echo "Error: This command line argument, \"$expression\", is/has an invalid expression." >&2
    exit $?
  fi
done

# ----------------------------------------
# initialize simulation properties - DO NOT MODIFY!
ELAB_OPTIONS=""
SIM_OPTIONS=""
if [[ `vcs -platform` != *"amd64"* ]]; then
  :
else
  :
fi

# ----------------------------------------
# create compilation libraries
mkdir -p ./libraries/work/
mkdir -p ./libraries/altera_avalon_onchip_memory2_170/
mkdir -p ./libraries/ghrd_10as066n2_onchip_memory2_0/
mkdir -p ./libraries/altera_avalon_mm_bridge_170/
mkdir -p ./libraries/ghrd_10as066n2_pb_lwh2f/
mkdir -p ./libraries/altera_jtag_dc_streaming_170/
mkdir -p ./libraries/timing_adapter_170/
mkdir -p ./libraries/altera_avalon_sc_fifo_170/
mkdir -p ./libraries/altera_avalon_st_bytes_to_packets_170/
mkdir -p ./libraries/altera_avalon_st_packets_to_bytes_170/
mkdir -p ./libraries/altera_avalon_packets_to_master_170/
mkdir -p ./libraries/channel_adapter_170/
mkdir -p ./libraries/altera_reset_controller_170/
mkdir -p ./libraries/altera_jtag_avalon_master_170/
mkdir -p ./libraries/ghrd_10as066n2_f2sdram_m1/
mkdir -p ./libraries/altera_avalon_fifo_170/
mkdir -p ./libraries/fifo_FPGA_to_HPS/
mkdir -p ./libraries/altera_avalon_pio_170/
mkdir -p ./libraries/ghrd_10as066n2_led_pio/
mkdir -p ./libraries/ghrd_10as066n2_clk_0/
mkdir -p ./libraries/altera_emif_arch_nf_170/
mkdir -p ./libraries/altera_emif_a10_hps_170/
mkdir -p ./libraries/ghrd_10as066n2_emif_a10_hps_0/
mkdir -p ./libraries/fifo_HPS_to_FPGA/
mkdir -p ./libraries/ghrd_10as066n2_f2sdram_m/
mkdir -p ./libraries/ghrd_10as066n2_fpga_m/
mkdir -p ./libraries/altera_arria10_interface_generator_140/
mkdir -p ./libraries/altera_arria10_hps_io_170/
mkdir -p ./libraries/altera_arria10_hps_170/
mkdir -p ./libraries/altera_avalon_sysid_qsys_170/
mkdir -p ./libraries/altera_merlin_slave_translator_170/
mkdir -p ./libraries/altera_merlin_axi_master_ni_170/
mkdir -p ./libraries/altera_merlin_slave_agent_170/
mkdir -p ./libraries/altera_merlin_router_170/
mkdir -p ./libraries/altera_merlin_traffic_limiter_170/
mkdir -p ./libraries/altera_merlin_burst_adapter_170/
mkdir -p ./libraries/altera_merlin_demultiplexer_170/
mkdir -p ./libraries/altera_merlin_multiplexer_170/
mkdir -p ./libraries/altera_merlin_width_adapter_170/
mkdir -p ./libraries/altera_avalon_st_pipeline_stage_170/
mkdir -p ./libraries/error_adapter_170/
mkdir -p ./libraries/altera_avalon_st_adapter_170/
mkdir -p ./libraries/altera_mm_interconnect_170/
mkdir -p ./libraries/altera_merlin_master_translator_170/
mkdir -p ./libraries/altera_merlin_master_agent_170/
mkdir -p ./libraries/altera_merlin_axi_slave_ni_170/
mkdir -p ./libraries/a10_devkit_flat/
mkdir -p ./libraries/altera_ver/
mkdir -p ./libraries/lpm_ver/
mkdir -p ./libraries/sgate_ver/
mkdir -p ./libraries/altera_mf_ver/
mkdir -p ./libraries/altera_lnsim_ver/
mkdir -p ./libraries/twentynm_ver/
mkdir -p ./libraries/twentynm_hssi_ver/
mkdir -p ./libraries/twentynm_hip_ver/

# ----------------------------------------
# copy RAM/ROM files to simulation directory
if [ $SKIP_FILE_COPY -eq 0 ]; then
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/altera_avalon_onchip_memory2_170/sim/ghrd_10as066n2_onchip_memory2_0_onchip_memory2_0.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_params_sim.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_params_synth.hex ./
  cp -f $QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_seq_cal.hex ./
fi

# ----------------------------------------
# compile device library files
if [ $SKIP_DEV_COM -eq 0 ]; then
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_primitives.v"                   -work altera_ver       
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/220model.v"                            -work lpm_ver          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/sgate.v"                               -work sgate_ver        
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_mf.v"                           -work altera_mf_ver    
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QUARTUS_INSTALL_DIR/eda/sim_lib/altera_lnsim.sv"                       -work altera_lnsim_ver 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_atoms.v"                      -work twentynm_ver     
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_atoms_ncrypt.v"      -work twentynm_ver     
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_hssi_atoms_ncrypt.v" -work twentynm_hssi_ver
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_hssi_atoms.v"                 -work twentynm_hssi_ver
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/synopsys/twentynm_hip_atoms_ncrypt.v"  -work twentynm_hip_ver 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QUARTUS_INSTALL_DIR/eda/sim_lib/twentynm_hip_atoms.v"                  -work twentynm_hip_ver 
fi

# ----------------------------------------
# compile design files in correct order
if [ $SKIP_COM -eq 0 ]; then
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/altera_avalon_onchip_memory2_170/sim/ghrd_10as066n2_onchip_memory2_0_altera_avalon_onchip_memory2_170_gyvpreq.v" -work altera_avalon_onchip_memory2_170      
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_onchip_memory2_0/sim/ghrd_10as066n2_onchip_memory2_0.v"                                                                           -work ghrd_10as066n2_onchip_memory2_0       
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_pb_lwh2f/altera_avalon_mm_bridge_170/sim/altera_avalon_mm_bridge.v"                                                               -work altera_avalon_mm_bridge_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_pb_lwh2f/sim/ghrd_10as066n2_pb_lwh2f.v"                                                                                           -work ghrd_10as066n2_pb_lwh2f               
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_jtag_interface.v"                                                    -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_dc_streaming.v"                                                           -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_sld_node.v"                                                               -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_jtag_streaming.v"                                                              -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_clock_crosser.v"                                                     -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_std_synchronizer_nocut.v"                                                      -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_base.v"                                                     -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_remover.v"                                                      -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_inserter.v"                                                     -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_stage.sv"                                                   -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/timing_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_timing_adapter_170_osazali.sv"                                        -work timing_adapter_170                    
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_sc_fifo_170/sim/altera_avalon_sc_fifo.v"                                                                 -work altera_avalon_sc_fifo_170             
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_st_bytes_to_packets_170/sim/altera_avalon_st_bytes_to_packets.v"                                         -work altera_avalon_st_bytes_to_packets_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_st_packets_to_bytes_170/sim/altera_avalon_st_packets_to_bytes.v"                                         -work altera_avalon_st_packets_to_bytes_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_avalon_packets_to_master_170/sim/altera_avalon_packets_to_master.v"                                             -work altera_avalon_packets_to_master_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_channel_adapter_170_bsi6toa.sv"                                      -work channel_adapter_170                   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m1_channel_adapter_170_xbvi4ny.sv"                                      -work channel_adapter_170                   
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_reset_controller_170/sim/altera_reset_controller.v"                                                             -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_reset_controller_170/sim/altera_reset_synchronizer.v"                                                           -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_f2sdram_m1_altera_jtag_avalon_master_170_vrhafhi.v"                   -work altera_jtag_avalon_master_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m1/sim/ghrd_10as066n2_f2sdram_m1.v"                                                                                       -work ghrd_10as066n2_f2sdram_m1             
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../fifo_FPGA_to_HPS/fifo_FPGA_to_HPS/altera_avalon_fifo_170/sim/fifo_FPGA_to_HPS_altera_avalon_fifo_170_gadxcxi.v"                                                    -work altera_avalon_fifo_170                
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../fifo_FPGA_to_HPS/fifo_FPGA_to_HPS/sim/fifo_FPGA_to_HPS.v"                                                                                                          -work fifo_FPGA_to_HPS                      
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_led_pio/altera_avalon_pio_170/sim/ghrd_10as066n2_led_pio_altera_avalon_pio_170_mhi24dy.v"                                         -work altera_avalon_pio_170                 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_led_pio/sim/ghrd_10as066n2_led_pio.v"                                                                                             -work ghrd_10as066n2_led_pio                
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_clk_0/sim/ghrd_10as066n2_clk_0.v"                                                                                                 -work ghrd_10as066n2_clk_0                  
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_top.sv"                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq_io_aux.sv"               -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_arch_nf_170_c6n6boq.sv"                      -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_bufs.sv"                                                           -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_se_i.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_se_o.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_df_i.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_df_o.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_udir_cp_i.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_bdir_df.sv"                                                    -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_bdir_se.sv"                                                    -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_buf_unused.sv"                                                     -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_cal_counter.sv"                                                    -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll.sv"                                                            -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll_fast_sim.sv"                                                   -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_pll_extra_clks.sv"                                                 -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_oct.sv"                                                            -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_core_clks_rsts.sv"                                                 -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hps_clks_rsts.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles_wrap.sv"                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles.sv"                                                       -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_io_tiles_abphy.sv"                                                 -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_abphy_mux.sv"                                                      -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_avl_if.sv"                                                     -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_sideband_if.sv"                                                -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_mmr_if.sv"                                                     -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_amm_data_if.sv"                                                -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_hmc_ast_data_if.sv"                                                -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_afi_if.sv"                                                         -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_seq_if.sv"                                                         -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_emif_arch_nf_regs.sv"                                                           -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_oct.sv"                                                                         -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_oct_um_fsm.sv"                                                                  -work altera_emif_arch_nf_170               
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/altera_std_synchronizer_nocut.v"                                                       -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/mem_array_abphy.sv"                                                                    -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_abphy.sv"                                                          -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_encrypted_abphy.sv"                                                -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/twentynm_io_12_lane_nf5es_encrypted_abphy.sv"                                          -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/io_12_lane_bcm__nf5es_abphy.sv"                                                        -work altera_emif_arch_nf_170               
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_arch_nf_170/sim/io_12_lane__nf5es_abphy.sv"                                                            -work altera_emif_arch_nf_170               
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/altera_emif_a10_hps_170/sim/ghrd_10as066n2_emif_a10_hps_0_altera_emif_a10_hps_170_65u4ugq.v"                       -work altera_emif_a10_hps_170               
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_emif_a10_hps_0/sim/ghrd_10as066n2_emif_a10_hps_0.v"                                                                               -work ghrd_10as066n2_emif_a10_hps_0         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../fifo_HPS_to_FPGA/fifo_HPS_to_FPGA/altera_avalon_fifo_170/sim/fifo_HPS_to_FPGA_altera_avalon_fifo_170_gadxcxi.v"                                                    -work altera_avalon_fifo_170                
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../fifo_HPS_to_FPGA/fifo_HPS_to_FPGA/sim/fifo_HPS_to_FPGA.v"                                                                                                          -work fifo_HPS_to_FPGA                      
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_jtag_interface.v"                                                     -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_jtag_dc_streaming.v"                                                            -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_jtag_sld_node.v"                                                                -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_jtag_streaming.v"                                                               -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_clock_crosser.v"                                                      -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_std_synchronizer_nocut.v"                                                       -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_base.v"                                                      -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_remover.v"                                                       -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_inserter.v"                                                      -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_stage.sv"                                                    -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/timing_adapter_170/sim/ghrd_10as066n2_f2sdram_m_timing_adapter_170_osazali.sv"                                          -work timing_adapter_170                    
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_avalon_sc_fifo_170/sim/altera_avalon_sc_fifo.v"                                                                  -work altera_avalon_sc_fifo_170             
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_avalon_st_bytes_to_packets_170/sim/altera_avalon_st_bytes_to_packets.v"                                          -work altera_avalon_st_bytes_to_packets_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_avalon_st_packets_to_bytes_170/sim/altera_avalon_st_packets_to_bytes.v"                                          -work altera_avalon_st_packets_to_bytes_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_avalon_packets_to_master_170/sim/altera_avalon_packets_to_master.v"                                              -work altera_avalon_packets_to_master_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m_channel_adapter_170_bsi6toa.sv"                                        -work channel_adapter_170                   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/channel_adapter_170/sim/ghrd_10as066n2_f2sdram_m_channel_adapter_170_xbvi4ny.sv"                                        -work channel_adapter_170                   
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_reset_controller_170/sim/altera_reset_controller.v"                                                              -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_reset_controller_170/sim/altera_reset_synchronizer.v"                                                            -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_f2sdram_m_altera_jtag_avalon_master_170_vrhafhi.v"                     -work altera_jtag_avalon_master_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_f2sdram_m/sim/ghrd_10as066n2_f2sdram_m.v"                                                                                         -work ghrd_10as066n2_f2sdram_m              
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_jtag_interface.v"                                                        -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_jtag_dc_streaming.v"                                                               -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_jtag_sld_node.v"                                                                   -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_jtag_streaming.v"                                                                  -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_clock_crosser.v"                                                         -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_std_synchronizer_nocut.v"                                                          -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_base.v"                                                         -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_remover.v"                                                          -work altera_jtag_dc_streaming_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_idle_inserter.v"                                                         -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_dc_streaming_170/sim/altera_avalon_st_pipeline_stage.sv"                                                       -work altera_jtag_dc_streaming_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/timing_adapter_170/sim/ghrd_10as066n2_fpga_m_timing_adapter_170_osazali.sv"                                                -work timing_adapter_170                    
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_avalon_sc_fifo_170/sim/altera_avalon_sc_fifo.v"                                                                     -work altera_avalon_sc_fifo_170             
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_avalon_st_bytes_to_packets_170/sim/altera_avalon_st_bytes_to_packets.v"                                             -work altera_avalon_st_bytes_to_packets_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_avalon_st_packets_to_bytes_170/sim/altera_avalon_st_packets_to_bytes.v"                                             -work altera_avalon_st_packets_to_bytes_170 
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_avalon_packets_to_master_170/sim/altera_avalon_packets_to_master.v"                                                 -work altera_avalon_packets_to_master_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/channel_adapter_170/sim/ghrd_10as066n2_fpga_m_channel_adapter_170_bsi6toa.sv"                                              -work channel_adapter_170                   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/channel_adapter_170/sim/ghrd_10as066n2_fpga_m_channel_adapter_170_xbvi4ny.sv"                                              -work channel_adapter_170                   
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_reset_controller_170/sim/altera_reset_controller.v"                                                                 -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_reset_controller_170/sim/altera_reset_synchronizer.v"                                                               -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/altera_jtag_avalon_master_170/sim/ghrd_10as066n2_fpga_m_altera_jtag_avalon_master_170_vrhafhi.v"                           -work altera_jtag_avalon_master_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../../ip/ghrd_10as066n2/ghrd_10as066n2_fpga_m/sim/ghrd_10as066n2_fpga_m.v"                                                                                               -work ghrd_10as066n2_fpga_m                 
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/verbosity_pkg.sv"                                                                                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_utilities_pkg.sv"                                                                                                   -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_mm_pkg.sv"                                                                                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_mm_slave_bfm.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/questa_mvc_svapi.svh"                                                                                                      -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_common_axi.sv"                                                                                                         -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_axi_master.sv"                                                                                                         -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/mgc_axi_slave.sv"                                                                                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_interrupt_sink.sv"                                                                                           -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_clock_source.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_reset_source.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_emif.sv"                                                    -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2h_axi_reset.sv"                                           -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_h2f_lw_axi_reset.sv"                                        -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_h2f_axi_reset.sv"                                           -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2sdram0_reset.sv"                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi_f2sdram2_reset.sv"                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_q5fiwxi.sv"                                                         -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/verbosity_pkg.sv"                                                                                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_utilities_pkg.sv"                                                                                                   -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/avalon_mm_pkg.sv"                                                                                                          -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_mm_slave_bfm.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_interrupt_sink.sv"                                                                                           -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_clock_source.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/altera_avalon_reset_source.sv"                                                                                             -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_auzrmda_hps_io.sv"                                                  -work altera_arria10_interface_generator_140
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_arria10_interface_generator_140/sim/a10_devkit_flat_altera_arria10_interface_generator_140_auzrmda.sv"                                                         -work altera_arria10_interface_generator_140
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_arria10_hps_io_170/sim/a10_devkit_flat_altera_arria10_hps_io_170_ka2odti.v"                                                                                    -work altera_arria10_hps_io_170             
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_arria10_hps_170/sim/a10_devkit_flat_altera_arria10_hps_170_qj4va5q.v"                                                                                          -work altera_arria10_hps_170                
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_avalon_sysid_qsys_170/sim/a10_devkit_flat_altera_avalon_sysid_qsys_170_g4vi2bq.v"                                                                              -work altera_avalon_sysid_qsys_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_slave_translator_170/sim/altera_merlin_slave_translator.sv"                                                                                             -work altera_merlin_slave_translator_170    
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_axi_master_ni_170/sim/altera_merlin_axi_master_ni.sv"                                                                                                   -work altera_merlin_axi_master_ni_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_axi_master_ni_170/sim/altera_merlin_address_alignment.sv"                                                                                               -work altera_merlin_axi_master_ni_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_slave_agent_170/sim/altera_merlin_slave_agent.sv"                                                                                                       -work altera_merlin_slave_agent_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_slave_agent_170/sim/altera_merlin_burst_uncompressor.sv"                                                                                                -work altera_merlin_slave_agent_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_avalon_sc_fifo_170/sim/altera_avalon_sc_fifo.v"                                                                                                                -work altera_avalon_sc_fifo_170             
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_kdhra7q.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_zislbwi.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_g4h2evy.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_merlin_traffic_limiter.sv"                                                                                               -work altera_merlin_traffic_limiter_170     
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_merlin_reorder_memory.sv"                                                                                                -work altera_merlin_traffic_limiter_170     
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_avalon_sc_fifo.v"                                                                                                        -work altera_merlin_traffic_limiter_170     
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_traffic_limiter_170/sim/altera_avalon_st_pipeline_base.v"                                                                                               -work altera_merlin_traffic_limiter_170     
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter.sv"                                                                                                   -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_uncmpr.sv"                                                                                            -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_13_1.sv"                                                                                              -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_burst_adapter_new.sv"                                                                                               -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_incr_burst_converter.sv"                                                                                                   -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_wrap_burst_converter.sv"                                                                                                   -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_default_burst_converter.sv"                                                                                                -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_merlin_address_alignment.sv"                                                                                               -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_avalon_st_pipeline_stage.sv"                                                                                               -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_burst_adapter_170/sim/altera_avalon_st_pipeline_base.v"                                                                                                 -work altera_merlin_burst_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_ncju4nq.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_sr2bqxy.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_ltwxniy.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_umxjhia.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_width_adapter_170/sim/altera_merlin_width_adapter.sv"                                                                                                   -work altera_merlin_width_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_width_adapter_170/sim/altera_merlin_address_alignment.sv"                                                                                               -work altera_merlin_width_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_width_adapter_170/sim/altera_merlin_burst_uncompressor.sv"                                                                                              -work altera_merlin_width_adapter_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_avalon_st_pipeline_stage_170/sim/altera_avalon_st_pipeline_stage.sv"                                                                                           -work altera_avalon_st_pipeline_stage_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_avalon_st_pipeline_stage_170/sim/altera_avalon_st_pipeline_base.v"                                                                                             -work altera_avalon_st_pipeline_stage_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../error_adapter_170/sim/a10_devkit_flat_error_adapter_170_mtlhioy.sv"                                                                                                   -work error_adapter_170                     
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_avalon_st_adapter_170/sim/a10_devkit_flat_altera_avalon_st_adapter_170_4tlgflq.v"                                                                              -work altera_avalon_st_adapter_170          
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../error_adapter_170/sim/a10_devkit_flat_error_adapter_170_7nlkpjq.sv"                                                                                                   -work error_adapter_170                     
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_avalon_st_adapter_170/sim/a10_devkit_flat_altera_avalon_st_adapter_170_4cxgu5y.v"                                                                              -work altera_avalon_st_adapter_170          
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_bedsd2q.v"                                                                                  -work altera_mm_interconnect_170            
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_master_translator_170/sim/altera_merlin_master_translator.sv"                                                                                           -work altera_merlin_master_translator_170   
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_master_agent_170/sim/altera_merlin_master_agent.sv"                                                                                                     -work altera_merlin_master_agent_170        
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_ehtz4ty.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_cmmikbq.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_azcyaiy.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_7uqpf4y.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_qsfnafa.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_q5jdrzq.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_e4h5cyi.v"                                                                                  -work altera_mm_interconnect_170            
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_s5homzq.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_3nv7wii.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_utyci7y.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_rodx5ey.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_dgamxba.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_xd2cdda.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_yclsorq.v"                                                                                  -work altera_mm_interconnect_170            
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_axi_slave_ni_170/sim/altera_merlin_axi_slave_ni.sv"                                                                                                     -work altera_merlin_axi_slave_ni_170        
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_axi_slave_ni_170/sim/altera_merlin_burst_uncompressor.sv"                                                                                               -work altera_merlin_axi_slave_ni_170        
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_merlin_axi_slave_ni_170/sim/altera_avalon_sc_fifo.v"                                                                                                           -work altera_merlin_axi_slave_ni_170        
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_axi_slave_ni_170/sim/altera_merlin_address_alignment.sv"                                                                                                -work altera_merlin_axi_slave_ni_170        
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_5fjswha.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_router_170/sim/a10_devkit_flat_altera_merlin_router_170_dlzuccy.sv"                                                                                     -work altera_merlin_router_170              
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_haephni.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_yfjobkq.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_demultiplexer_170/sim/a10_devkit_flat_altera_merlin_demultiplexer_170_v76hp2y.sv"                                                                       -work altera_merlin_demultiplexer_170       
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/a10_devkit_flat_altera_merlin_multiplexer_170_ek47qgi.sv"                                                                           -work altera_merlin_multiplexer_170         
  vlogan +v2k -sverilog $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS "$QSYS_SIMDIR/../altera_merlin_multiplexer_170/sim/altera_merlin_arbitrator.sv"                                                                                                        -work altera_merlin_multiplexer_170         
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_bpwwuey.v"                                                                                  -work altera_mm_interconnect_170            
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_mm_interconnect_170/sim/a10_devkit_flat_altera_mm_interconnect_170_piph77i.v"                                                                                  -work altera_mm_interconnect_170            
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_reset_controller_170/sim/altera_reset_controller.v"                                                                                                            -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/../altera_reset_controller_170/sim/altera_reset_synchronizer.v"                                                                                                          -work altera_reset_controller_170           
  vlogan +v2k $USER_DEFINED_VERILOG_COMPILE_OPTIONS $USER_DEFINED_COMPILE_OPTIONS           "$QSYS_SIMDIR/a10_devkit_flat.v"                                                                                                                                                       -work a10_devkit_flat                       
fi

# ----------------------------------------
# elaborate top level design
if [ $SKIP_ELAB -eq 0 ]; then
  vcs -lca -t ps $ELAB_OPTIONS $USER_DEFINED_ELAB_OPTIONS $TOP_LEVEL_NAME
fi

# ----------------------------------------
# simulate
if [ $SKIP_SIM -eq 0 ]; then
  ./simv $SIM_OPTIONS $USER_DEFINED_SIM_OPTIONS
fi
